from django.db import models

# Create your models here.
class studentmodel(models.Model):
        username = models.CharField(max_length=100)
        emailid = models.CharField(max_length=100)
        city = models.CharField(max_length=100)
        currenttime = models.CharField(max_length=100)
        class Meta:
                db_table="user"