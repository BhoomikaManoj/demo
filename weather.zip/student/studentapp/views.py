import imp
from django.shortcuts import render,redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from studentapp.models import studentmodel
import urllib.request
import json
import requests
from django.core.mail import send_mail

def home(request):
    if request.method == 'POST':
        city = request.POST.get('city')

        base_url = "http://api.openweathermap.org/data/2.5/weather?"
        complete_url = base_url + "appid=" + 'be535c83f4e8f62c2ab4f9442e22f561' + "&q=" + city  # This is to complete the base_url, you can also do this manually to checkout other weather data available
        response = requests.get(complete_url)
        list_of_data = response.json()   # its in dictionary
       
        # source = urllib.request.urlopen('http://api.openweathermap.org/data/2.5/weather?' + 'q=' + city + '&appid =be535c83f4e8f62c2ab4f9442e22f561').read()

        # convert Json data to dictionary
        # list_of_data = json.loads(source)

        data = {
            "country_code": str(list_of_data['sys']['country']),
            "coordinate": str(list_of_data['coord']['lon']) + ' '
                + str(list_of_data['coord']['lat']),
            "temp": str(list_of_data['main']['temp']) + 'k',
            "pressure": str(list_of_data['main']['pressure']),
            "humidity": str(list_of_data['main']['humidity'])
        }
        context = {
            'data': data,
        }
        return render(request,'home.html',data)
    else:
        data = ''
        context = {
            'data': data,
        }

    return render(request,'home.html',context)

# Create your views here.
def register(request):
    if request.method == 'POST':
        if(request.POST.get('username') and request.POST.get('emailid') and request.POST.get('city') and request.POST.get('currenttime')):
            sending_emailid = request.POST.get('emailid')
            user_name = request.POST.get('username')
            send_mail(
                "welcome",
                "Hi " + user_name + " interested in our services",
                ["Bhoomikagl95@gmail.com"],
                [sending_emailid]
            )

            saverecord=studentmodel()
            saverecord.username=request.POST.get('username')
            saverecord.emailid=request.POST.get('emailid')
            saverecord.city=request.POST.get('city')
            saverecord.currenttime=request.POST.get('currenttime')

            saverecord.save()
            messages.success(request,"new user registration details saved successsfully")
            return render(request,'register.html')
    else:
        return render(request,'register.html')

